LAMMPS (22 Jul 2025 - Update 4)
KOKKOS mode with Kokkos version 4.6.2 is enabled
  will use up to 1 GPU(s) per node
package kokkos
package kokkos newton on neigh half gpu/aware off
# Static response of the aluminium matrix to a given strain of the inclusion.
#
# The input is either the relaxed reference cell or the same cell after
# scripts/make_strained_inclusion.py has moved the inclusion atoms by the
# magnetostrictive strain (and, optionally, the matrix atoms by the continuum
# displacement as a starting guess). The inclusion atoms are kept where they
# are (zero force); only the matrix atoms relax, by conjugate gradients, at a
# fixed box (zero mean strain). Both members of a pair go through this input.
# There is no thermal stage.
#
# The box is not relaxed on purpose: with the inclusion held, the virial of the
# cell contains the inclusion's own elastic stress but not the holding forces,
# so driving it to zero would not describe a stress-free body. A fixed box is a
# clean boundary condition that the continuum reference reproduces exactly.
#
# CG runs in chunks of CHUNK iterations (a restart resets the conjugate
# directions and breaks silent stalls), first to FTOL_A, with a dump, then on
# to FTOL_B; comparing the two dumps shows whether the field still changes.
#
# Metal units: angstrom, eV, bar. stress/atom values are in bar*A^3.
# Variables (-var): DATA_FILE POT_DIR OUT_PREFIX N_AL
#   FTOL_A, FTOL_B   force two-norms of the two stages, eV/A   (0.001, 0.0003)
#   CHUNK, NCHUNK    iterations per chunk, maximum chunks      (2000, 12)
# Atom types: 1 Al, 2 Fe, 3 Mg, 4 Si. Periodic in x, y and z.

units           metal
atom_style      atomic
boundary        p p p

variable        FTOL_A index 0.001
variable        FTOL_B index 0.0003
variable        CHUNK index 2000
variable        NCHUNK index 12

read_data       ${DATA_FILE}
read_data       x10.data
Reading data file ...
  orthogonal box = (0.034120475 0.033578634 0.034190899) to (125.97231 123.97184 126.23231)
  1 by 1 by 1 MPI processor grid
  reading atoms ...
  118861 atoms
  read_data CPU = 0.484 seconds

pair_style      meam
pair_coeff      * * ${POT_DIR}/Jelinek_2012_meamf AlS SiS MgS CuS FeS ${POT_DIR}/Jelinek_2012_meam.alsimgcufe AlS FeS MgS SiS
pair_coeff      * * C:/Users/dille/Documents/ilua-system/projects/physics_md_al_fe/potentials/meam/Jelinek_2012/Jelinek_2012_meamf AlS SiS MgS CuS FeS ${POT_DIR}/Jelinek_2012_meam.alsimgcufe AlS FeS MgS SiS
pair_coeff      * * C:/Users/dille/Documents/ilua-system/projects/physics_md_al_fe/potentials/meam/Jelinek_2012/Jelinek_2012_meamf AlS SiS MgS CuS FeS C:/Users/dille/Documents/ilua-system/projects/physics_md_al_fe/potentials/meam/Jelinek_2012/Jelinek_2012_meam.alsimgcufe AlS FeS MgS SiS

neighbor        2.0 bin
neigh_modify    delay 0 every 1 check no
compute         st all stress/atom NULL virial

variable        first_incl equal v_N_AL+1
group           inclusion id ${first_incl}:999999999
group           inclusion id 114375:999999999
4487 atoms in group inclusion
group           matrix subtract all inclusion
114374 atoms in group matrix
fix             freeze inclusion setforce 0.0 0.0 0.0

thermo          200
thermo_style    custom step pe press pxx pyy pzz pxz pxy pyz fnorm fmax
thermo_modify   flush yes
min_style       cg
min_modify      dmax 0.05

variable        k loop ${NCHUNK}
variable        k loop 5
label           cgA
minimize        0.0 ${FTOL_A} ${CHUNK} 60000
minimize        0.0 0.003 ${CHUNK} 60000
minimize        0.0 0.003 2000 60000
Neighbor list info ...
  update: every = 1 steps, delay = 0 steps, check = no
  max neighbors/atom: 2000, page size: 100000
  master list distance cutoff = 7
  ghost atom cutoff = 7
  binsize = 7, bins = 18 18 19
  2 neighbor lists, perpetual/occasional/extra = 2 0 0
  (1) pair meam/kk, perpetual
      attributes: full, newton on, kokkos_device
      pair build: full/bin/kk/device
      stencil: full/bin/3d
      bin: kk/device
  (2) pair meam/kk, perpetual, half/full from (1)
      attributes: half, newton on, kokkos_device
      pair build: halffull/newton/kk/device
      stencil: none
      bin: none
WARNING: Fix MINIMIZE/kk not compatible with sending data in Kokkos communication (C:\Users\dille\Documents\builds\lammps-kokkos-cuda\lammps\src\KOKKOS\comm_kokkos.cpp:799)
WARNING: Fix with atom-based arrays not compatible with sending data in Kokkos communication, switching to classic exchange/border communication (C:\Users\dille\Documents\builds\lammps-kokkos-cuda\lammps\src\KOKKOS\comm_kokkos.cpp:812)
WARNING: Fix MINIMIZE/kk not compatible with Kokkos sorting on device (C:\Users\dille\Documents\builds\lammps-kokkos-cuda\lammps\src\KOKKOS\atom_kokkos.cpp:213)
WARNING: Fix with atom-based arrays not compatible with Kokkos sorting on device, switching to classic host sorting (C:\Users\dille\Documents\builds\lammps-kokkos-cuda\lammps\src\KOKKOS\atom_kokkos.cpp:219)
Per MPI rank memory allocation (min/avg/max) = 198.2 | 198.2 | 198.2 Mbytes
   Step         PotEng         Press           Pxx            Pyy            Pzz            Pxz            Pxy            Pyz           Fnorm           Fmax     
         0  -398489.59      2456.9039      2176.4832      2157.3335      3036.895      -356.18723     -30.165416     -83.801685      25.221046      3.8852352    
       200  -398535.55      2384.0136      1912.114       2172.7803      3067.1464     -373.21411     -35.119926     -62.849871      0.017956994    0.009512057  
       387  -398535.57      2383.3722      1913.6487      2170.5658      3065.902      -372.18794     -34.68048      -63.636738      0.0029708321   0.0010656552 
Loop time of 307.279 on 1 procs for 387 steps with 118861 atoms

97.7% CPU use with 1 MPI tasks x 1 OpenMP threads

Minimization stats:
  Stopping criterion = force tolerance
  Energy initial, next-to-last, final = 
     -398489.588669819  -398535.568012615  -398535.568013101
  Force two-norm initial, final = 25.221046 0.0029708321
  Force max component initial, final = 3.8852352 0.0010656552
  Final line search alpha, max atom move = 1 0.0010656552
  Iterations, force evaluations = 387 754

MPI task timing breakdown:
Section |  min time  |  avg time  |  max time  |%varavg| %total
---------------------------------------------------------------
Pair    | 295.95     | 295.95     | 295.95     |   0.0 | 96.31
Neigh   | 7.2444     | 7.2444     | 7.2444     |   0.0 |  2.36
Comm    | 2.2882     | 2.2882     | 2.2882     |   0.0 |  0.74
Output  | 0.0010899  | 0.0010899  | 0.0010899  |   0.0 |  0.00
Modify  | 0.17861    | 0.17861    | 0.17861    |   0.0 |  0.06
Other   |            | 1.615      |            |       |  0.53

Nlocal:         118861 ave      118861 max      118861 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Nghost:          43200 ave       43200 max       43200 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Neighs:     4.7228e+06 ave  4.7228e+06 max  4.7228e+06 min
Histogram: 1 0 0 0 0 0 0 0 0 0
FullNghs:  9.44561e+06 ave 9.44561e+06 max 9.44561e+06 min
Histogram: 1 0 0 0 0 0 0 0 0 0

Total # of neighbors = 9445606
Ave neighs/atom = 79.467664
Neighbor list builds = 755
Dangerous builds not checked
variable        fn equal fnorm
print           "CHUNK A $k fnorm $(v_fn)"
CHUNK A 1 fnorm 0.0029708321252043699487
if "$(v_fn) < ${FTOL_A}" then "jump SELF doneA"
jump SELF doneA
variable        k delete
write_dump      all custom ${OUT_PREFIX}.static1.lammpstrj id type x y z c_st[1] c_st[2] c_st[3] c_st[4] c_st[5] c_st[6] modify sort id format float %.8g
write_dump      all custom x10.static1.lammpstrj id type x y z c_st[1] c_st[2] c_st[3] c_st[4] c_st[5] c_st[6] modify sort id format float %.8g

variable        k loop ${NCHUNK}
variable        k loop 5
label           cgB
minimize        0.0 ${FTOL_B} ${CHUNK} 60000
minimize        0.0 0.001 ${CHUNK} 60000
minimize        0.0 0.001 2000 60000
WARNING: Fix MINIMIZE/kk not compatible with Kokkos sorting on device (C:\Users\dille\Documents\builds\lammps-kokkos-cuda\lammps\src\KOKKOS\atom_kokkos.cpp:213)
WARNING: Fix with atom-based arrays not compatible with Kokkos sorting on device, switching to classic host sorting (C:\Users\dille\Documents\builds\lammps-kokkos-cuda\lammps\src\KOKKOS\atom_kokkos.cpp:219)
Per MPI rank memory allocation (min/avg/max) = 205.8 | 205.8 | 205.8 Mbytes
   Step         PotEng         Press           Pxx            Pyy            Pzz            Pxz            Pxy            Pyz           Fnorm           Fmax     
       387  -398535.57      2383.3722      1913.6487      2170.5658      3065.902      -372.18794     -34.68048      -63.636738      0.0029708321   0.0010656552 
       400  -398535.57      2383.3751      1913.6507      2170.57        3065.9047     -372.18629     -34.682569     -63.635056      0.0016009613   0.00031472834
       532  -398535.57      2383.38        1913.671       2170.5655      3065.9035     -372.18091     -34.682965     -63.622217      0.0009745139   0.00023367072
Loop time of 117.185 on 1 procs for 145 steps with 118861 atoms

96.9% CPU use with 1 MPI tasks x 1 OpenMP threads

Minimization stats:
  Stopping criterion = force tolerance
  Energy initial, next-to-last, final = 
     -398535.568013101  -398535.568060471  -398535.568060553
  Force two-norm initial, final = 0.0029708321 0.0009745139
  Force max component initial, final = 0.0010656552 0.00023367072
  Final line search alpha, max atom move = 1 0.00023367072
  Iterations, force evaluations = 145 290

MPI task timing breakdown:
Section |  min time  |  avg time  |  max time  |%varavg| %total
---------------------------------------------------------------
Pair    | 112.88     | 112.88     | 112.88     |   0.0 | 96.33
Neigh   | 2.7929     | 2.7929     | 2.7929     |   0.0 |  2.38
Comm    | 0.84878    | 0.84878    | 0.84878    |   0.0 |  0.72
Output  | 0.0013125  | 0.0013125  | 0.0013125  |   0.0 |  0.00
Modify  | 0.066792   | 0.066792   | 0.066792   |   0.0 |  0.06
Other   |            | 0.5907     |            |       |  0.50

Nlocal:         118861 ave      118861 max      118861 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Nghost:          43200 ave       43200 max       43200 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Neighs:    4.72281e+06 ave 4.72281e+06 max 4.72281e+06 min
Histogram: 1 0 0 0 0 0 0 0 0 0
FullNghs:  9.44561e+06 ave 9.44561e+06 max 9.44561e+06 min
Histogram: 1 0 0 0 0 0 0 0 0 0

Total # of neighbors = 9445612
Ave neighs/atom = 79.467714
Neighbor list builds = 291
Dangerous builds not checked
variable        fn equal fnorm
print           "CHUNK B $k fnorm $(v_fn)"
CHUNK B 1 fnorm 0.00097451390154870199713
if "$(v_fn) < ${FTOL_B}" then "jump SELF doneB"
jump SELF doneB
write_dump      all custom ${OUT_PREFIX}.static.lammpstrj id type x y z c_st[1] c_st[2] c_st[3] c_st[4] c_st[5] c_st[6] modify sort id format float %.8g
write_dump      all custom x10.static.lammpstrj id type x y z c_st[1] c_st[2] c_st[3] c_st[4] c_st[5] c_st[6] modify sort id format float %.8g
write_data      ${OUT_PREFIX}.static.data
write_data      x10.static.data
System init for write_data ...

# Forces that keep the inclusion in its shape: release the constraint and
# evaluate the forces once, at the minimised positions, without moving atoms.
unfix           freeze
run             0
WARNING: No fixes with time integration, atoms won't move
For more information see https://docs.lammps.org/err0028 (C:\Users\dille\Documents\builds\lammps-kokkos-cuda\lammps\src\verlet.cpp:60)
Per MPI rank memory allocation (min/avg/max) = 194.6 | 194.6 | 194.6 Mbytes
   Step         PotEng         Press           Pxx            Pyy            Pzz            Pxz            Pxy            Pyz           Fnorm           Fmax     
       532  -398535.57      2383.38        1913.671       2170.5655      3065.9035     -372.18091     -34.682965     -63.622217      77.930397      3.8191231    
Loop time of 0.0007381 on 1 procs for 0 steps with 118861 atoms

0.0% CPU use with 1 MPI tasks x 1 OpenMP threads

MPI task timing breakdown:
Section |  min time  |  avg time  |  max time  |%varavg| %total
---------------------------------------------------------------
Pair    | 0          | 0          | 0          |   0.0 |  0.00
Neigh   | 0          | 0          | 0          |   0.0 |  0.00
Comm    | 0          | 0          | 0          |   0.0 |  0.00
Output  | 0          | 0          | 0          |   0.0 |  0.00
Modify  | 0          | 0          | 0          |   0.0 |  0.00
Other   |            | 0.0007381  |            |       |100.00

Nlocal:         118861 ave      118861 max      118861 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Nghost:          43200 ave       43200 max       43200 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Neighs:    4.72281e+06 ave 4.72281e+06 max 4.72281e+06 min
Histogram: 1 0 0 0 0 0 0 0 0 0
FullNghs:  9.44561e+06 ave 9.44561e+06 max 9.44561e+06 min
Histogram: 1 0 0 0 0 0 0 0 0 0

Total # of neighbors = 9445612
Ave neighs/atom = 79.467714
Neighbor list builds = 0
Dangerous builds not checked
write_dump      inclusion custom ${OUT_PREFIX}.forces.lammpstrj id type x y z fx fy fz modify sort id format float %.8g
write_dump      inclusion custom x10.forces.lammpstrj id type x y z fx fy fz modify sort id format float %.8g
Total wall time: 0:07:07
